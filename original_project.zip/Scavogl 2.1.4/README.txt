!match scavogl //4v4 Normal
!forcematch scavogl

!match scavogl-hr //4v4 with 1 Hunting Rifle
!forcematch scavogl-hr

!match scavogl1v1 //1v1 Hunters Only
!forcematch scavogl1v1

!match scavogl2v2 //2v2 - Charger/Jockey/Hunter
!forcematch scavogl2v2

!match scavogl2v2-hr //2v2 with 1 Hunting Rifle - Charger/Jockey/Hunter
!forcematch scavogl2v2-hr

!match scavogl3v3 //3v3 - Charger/Jockey/Hunter/Smoker
!forcematch scavogl3v3

!match scavogl3v3-hr //3v3 with 1 Hunting Rifle - Charger/Jockey/Hunter/Smoker
!forcematch scavogl3v3-hr

!match scavoglhunters //4v4 Hunters Only
!forcematch scavoglhunters

!match scavoglhunters2v2 //2v2 Hunters Only
!forcematch scavoglhunters2v2

!match scavoglhunters3v3 //3v3 Hunters Only
!forcematch scavoglhunter3v3